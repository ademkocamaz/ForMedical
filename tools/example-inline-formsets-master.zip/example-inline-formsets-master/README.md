# Example MyCollections app
Using Django inline formsets with Class-based Views and crispy-forms

## Installation

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py collectstatic
python manage.py runserver
```
Development server runs at `localhost:8000`
