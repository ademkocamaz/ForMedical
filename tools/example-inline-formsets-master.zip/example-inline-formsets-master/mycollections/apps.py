from django.apps import AppConfig


class MycollectionsConfig(AppConfig):
    name = 'mycollections'
