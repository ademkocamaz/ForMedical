# boilerplate-django-adminlte
# [AdminLTE - Bootstrap 4 Admin Dashboard on Django](https://adminlte.io)

Boilerplate of AdminLTE on Django

**AdminLTE** is a fully responsive administration template. Based on **[Bootstrap 4.6](https://getbootstrap.com/)** framework and also the JS/jQuery plugin.
Highly customizable and easy to use. Fits many screen resolutions from small mobile devices to large desktops.

**Preview on [AdminLTE.io](https://adminlte.io/themes/v3)**